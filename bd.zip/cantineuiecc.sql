-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 22, 2022 at 10:32 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cantineuiecc`
--

-- --------------------------------------------------------

--
-- Table structure for table `cantine`
--

DROP TABLE IF EXISTS `cantine`;
CREATE TABLE IF NOT EXISTS `cantine` (
  `idCantine` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `idTicket` int(11) NOT NULL,
  `idRepas` int(11) NOT NULL,
  PRIMARY KEY (`idCantine`),
  KEY `ticket_cantine_fk` (`idTicket`),
  KEY `repas_cantine_fk` (`idRepas`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gerant`
--

DROP TABLE IF EXISTS `gerant`;
CREATE TABLE IF NOT EXISTS `gerant` (
  `idPersonne` int(11) NOT NULL,
  `matriculeGerant` varchar(8) NOT NULL,
  PRIMARY KEY (`idPersonne`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `personne`
--

DROP TABLE IF EXISTS `personne`;
CREATE TABLE IF NOT EXISTS `personne` (
  `idPersonne` int(11) NOT NULL AUTO_INCREMENT,
  `prenom` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `dateEnregistrement` datetime NOT NULL,
  `motDePasse` varchar(15) NOT NULL,
  `login` varchar(15) NOT NULL,
  `numeroTelephone` int(11) NOT NULL,
  `email` varchar(25) NOT NULL,
  `idCantine` int(11) NOT NULL,
  PRIMARY KEY (`idPersonne`),
  KEY `cantine_personne_fk` (`idCantine`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `repas`
--

DROP TABLE IF EXISTS `repas`;
CREATE TABLE IF NOT EXISTS `repas` (
  `idRepas` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `idTicket` int(11) NOT NULL,
  `idCantine` int(11) NOT NULL,
  PRIMARY KEY (`idRepas`),
  KEY `ticket_repas_fk` (`idTicket`),
  KEY `cantine_repas_fk` (`idCantine`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `idPersonne` int(11) NOT NULL,
  `matricule` varchar(8) NOT NULL,
  PRIMARY KEY (`idPersonne`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE IF NOT EXISTS `ticket` (
  `idTicket` int(11) NOT NULL AUTO_INCREMENT,
  `dureeValidite` int(11) NOT NULL,
  `idPersonne` int(11) NOT NULL,
  `idCantine` int(11) NOT NULL,
  `idRepas` int(11) NOT NULL,
  PRIMARY KEY (`idTicket`),
  KEY `gerant_ticket_fk` (`idPersonne`),
  KEY `cantine_ticket_fk` (`idCantine`),
  KEY `repas_ticket_fk` (`idRepas`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `travailpour`
--

DROP TABLE IF EXISTS `travailpour`;
CREATE TABLE IF NOT EXISTS `travailpour` (
  `idPersonne` int(11) NOT NULL,
  `idCantine` int(11) NOT NULL,
  PRIMARY KEY (`idPersonne`,`idCantine`),
  KEY `cantine_travailpour_fk` (`idCantine`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
