
CREATE TABLE personne (
                idPersonne INT AUTO_INCREMENT NOT NULL,
                prenom VARCHAR(50) NOT NULL,
                nom VARCHAR(50) NOT NULL,
                dateEnregistrement DATETIME NOT NULL,
                motDePasse VARCHAR(15) NOT NULL,
                login VARCHAR(15) NOT NULL,
                numeroTelephone INT NOT NULL,
                email VARCHAR(25) NOT NULL,
                idCantine INT NOT NULL,
                PRIMARY KEY (idPersonne)
);


CREATE TABLE student (
                idPersonne INT NOT NULL,
                matricule VARCHAR(8) NOT NULL,
                PRIMARY KEY (idPersonne)
);


CREATE TABLE gerant (
                idPersonne INT NOT NULL,
                matriculeGerant VARCHAR(8) NOT NULL,
                PRIMARY KEY (idPersonne)
);


CREATE TABLE ticket (
                idTicket INT AUTO_INCREMENT NOT NULL,
                dureeValidite INT NOT NULL,
                idPersonne INT NOT NULL,
                idCantine INT NOT NULL,
                idRepas INT NOT NULL,
                PRIMARY KEY (idTicket)
);


CREATE TABLE cantine (
                idCantine INT AUTO_INCREMENT NOT NULL,
                nom VARCHAR(50) NOT NULL,
                idTicket INT NOT NULL,
                idRepas INT NOT NULL,
                PRIMARY KEY (idCantine)
);


CREATE TABLE repas (
                idRepas INT AUTO_INCREMENT NOT NULL,
                nom VARCHAR(50) NOT NULL,
                idTicket INT NOT NULL,
                idCantine INT NOT NULL,
                PRIMARY KEY (idRepas)
);


CREATE TABLE travailPour (
                idPersonne INT NOT NULL,
                idCantine INT NOT NULL,
                PRIMARY KEY (idPersonne, idCantine)
);


ALTER TABLE gerant ADD CONSTRAINT personne_gerant_fk
FOREIGN KEY (idPersonne)
REFERENCES personne (idPersonne)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE student ADD CONSTRAINT personne_student_fk
FOREIGN KEY (idPersonne)
REFERENCES personne (idPersonne)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ticket ADD CONSTRAINT personne_ticket_fk
FOREIGN KEY (idPersonne)
REFERENCES personne (idPersonne)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ticket ADD CONSTRAINT gerant_ticket_fk
FOREIGN KEY (idPersonne)
REFERENCES gerant (idPersonne)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE travailPour ADD CONSTRAINT gerant_travailpour_fk
FOREIGN KEY (idPersonne)
REFERENCES gerant (idPersonne)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE cantine ADD CONSTRAINT ticket_cantine_fk
FOREIGN KEY (idTicket)
REFERENCES ticket (idTicket)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE repas ADD CONSTRAINT ticket_repas_fk
FOREIGN KEY (idTicket)
REFERENCES ticket (idTicket)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE personne ADD CONSTRAINT cantine_personne_fk
FOREIGN KEY (idCantine)
REFERENCES cantine (idCantine)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ticket ADD CONSTRAINT cantine_ticket_fk
FOREIGN KEY (idCantine)
REFERENCES cantine (idCantine)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE travailPour ADD CONSTRAINT cantine_travailpour_fk
FOREIGN KEY (idCantine)
REFERENCES cantine (idCantine)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE repas ADD CONSTRAINT cantine_repas_fk
FOREIGN KEY (idCantine)
REFERENCES cantine (idCantine)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE ticket ADD CONSTRAINT repas_ticket_fk
FOREIGN KEY (idRepas)
REFERENCES repas (idRepas)
ON DELETE NO ACTION
ON UPDATE NO ACTION;

ALTER TABLE cantine ADD CONSTRAINT repas_cantine_fk
FOREIGN KEY (idRepas)
REFERENCES repas (idRepas)
ON DELETE NO ACTION
ON UPDATE NO ACTION;
